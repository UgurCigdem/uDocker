#!/bin/bash
# Show LiteLLM Proxy status

echo "📊 LiteLLM Proxy Status:"
echo ""
docker compose ps
echo ""

if docker compose ps | grep litellm-proxy | grep -q Up; then
    echo "✅ Status: LÄUFT"
    echo "   Erreichbar: http://localhost:4000"
    echo "   Modell-Endpunkt: curl http://localhost:4000/models"
else
    echo "⏸ Status: GESTOPPT"
fi
