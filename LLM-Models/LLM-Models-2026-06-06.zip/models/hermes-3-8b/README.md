# hermes-3-8b — vLLM Model

## 📋 Model Bilgisi

| Özellik | Değer |
|---------|-------|
| **Model Adı** | NousResearch/Hermes-3-Llama-3.1-8B |
| **Parametreler** | 8B |
| **Mimari** | Dense (Llama 3.1 fine-tune) |
| **Boyut** | 18 GB disk |
| **GPU Bellek** | 0.3 (= 30%) |
| **Max Context** | 131072 tokens |
| **Quantization** | FP16 (float16) |
| **Port** | 8004 |
| **Container** | `vllm-hermes-3-8b` |
| **Docker Image** | `vllm/vllm-openai:latest` |

---

## 🎯 Ne İş İçin Uygun?

Langer Kontext (128K) + Function Calling

### Kullanım Senaryoları

- Function/Tool Calling — externe API-Integration
- Agent-Verhalten — mehrstufige Aufgabensteuerung
- Claude-Code-Standardmodell (lokal)
- Analyse langer Dokumente (128K ≈ 300 Seiten)
- RAG-Backend (Retrieval Augmented Generation)
- Chain-of-Thought-Reasoning
- Strukturierte JSON-Ausgabe erzeugen

---

## 🚀 Başlatma

### İlk Kez
```bash
cd hermes-3-8b
./install.sh        # Model indir + container oluştur + başlat
```

### Sonraki Sefer
```bash
cd hermes-3-8b
./start.sh          # Container başlat (model cache'de)
```

### Durdurma (cache korunur)
```bash
./stop.sh
```

---

## 📡 API Erişim

### vLLM Doğrudan
```bash
# Model listesi
curl http://localhost:8004/v1/models

# Chat completion
curl -X POST http://localhost:8004/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "hermes-3-8b",
    "messages": [{"role": "user", "content": "Hello"}],
    "max_tokens": 512
  }'
```

### LiteLLM Gateway Üzerinden
```bash
curl -X POST http://localhost:4000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "hermes-3-8b",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

---

## 💾 Yönetim

| İşlem | Komut |
|-------|-------|
| **Durum Kontrol** | `./status.sh` |
| **Logları İzle** | `./logs.sh -f` |
| **Kaldır** | `./uninstall.sh` |

---

## 📊 Performans Tahmini

- **İlk Yükleme:** 5-10 dakika (model indir + CUDA graph capture)
- **Restart:** 2-3 saniye (cache'ten)
- **Çıktı Hızı:** 50-100 token/s (GPU'ya bağlı)

---

## 🔗 Kaynaklar

- **HF Sayfası:** https://huggingface.co/NousResearch/Hermes-3-Llama-3.1-8B
- **vLLM Docs:** https://docs.vllm.ai/
- **Ana README:** `../README.md`

---

**Kurulum tarihi:** 2026-05-17
