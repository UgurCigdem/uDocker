#!/bin/bash
# Install LiteLLM Proxy Gateway
# Routes requests to local vLLM models + cloud fallback

set -e

echo "🚀 Installiere LiteLLM Proxy..."
echo ""

# Check network
if ! docker network ls | grep -q ai-net; then
    echo "❌ Netzwerk 'ai-net' nicht gefunden."
    echo "Aus übergeordnetem Ordner ausführen: ../setup-network.sh"
    exit 1
fi

# Check docker-compose.yml
if [ ! -f "docker-compose.yml" ]; then
    echo "❌ docker-compose.yml nicht gefunden"
    exit 1
fi

# Create .env from example if needed
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "⚠ .env aus .env.example erstellt"
    echo "  .env bearbeiten, um Cloud-API-Keys hinzuzufügen (optional)"
fi

# Create logs directory
mkdir -p logs

# Start LiteLLM proxy
echo "📦 Starte LiteLLM-Container..."
docker compose up -d

echo "⏳ Warte auf LiteLLM-Start..."
sleep 3

# Check health
MAX_WAIT=60
ELAPSED=0

while [ $ELAPSED -lt $MAX_WAIT ]; do
    if docker compose ps | grep litellm-proxy | grep -q Up; then
        # Try health endpoint
        if curl -s http://localhost:4000/health > /dev/null 2>&1; then
            echo "✅ LiteLLM Proxy läuft und ist gesund!"
            echo ""
            echo "📡 Erreichbar:"
            echo "   Gateway: http://localhost:4000"
            echo "   Modelle: http://localhost:4000/models"
            echo "   Status: curl http://localhost:4000/health"
            echo ""
            echo "Beispiel-Anfrage:"
            echo "  curl -X POST http://localhost:4000/chat/completions \\"
            echo "    -H 'Content-Type: application/json' \\"
            echo "    -d '{\"model\": \"coder\", \"messages\": [{\"role\": \"user\", \"content\": \"hello\"}]}'"
            echo ""
            exit 0
        fi
    fi

    ELAPSED=$((ELAPSED + 2))
    if [ $((ELAPSED % 10)) -eq 0 ]; then
        echo "   Startet noch... ($ELAPSED/$MAX_WAIT Sekunden)"
    fi
    sleep 2
done

echo "❌ Zeitüberschreitung beim Start von LiteLLM"
echo ""
echo "Logs prüfen:"
echo "  docker compose logs -f litellm-proxy"
echo ""
exit 1
