# gemma-4-31b-it — vLLM Model

## 📋 Model Bilgisi

| Özellik | Değer |
|---------|-------|
| **Model Adı** | google/gemma-4-31B-it |
| **Parametreler** | 31B |
| **Mimari** | Dense (Gemma 4) |
| **Boyut** | 65 GB disk |
| **GPU Bellek** | 0.7 (= 70%) |
| **Max Context** | 16384 tokens |
| **Quantization** | BF16 (bfloat16) |
| **Port** | 8008 |
| **Container** | `vllm-gemma-4-31b-it` |
| **Docker Image** | `vllm/vllm-openai:nightly-aarch64` |

---

## 🎯 Ne İş İçin Uygun?

Dense 31B — stärkstes Gemma 4, Kontext 16K (Speichergrenze)

### Kullanım Senaryoları

- Aufgaben höchster Qualität (das stärkste der Gemma-Familie)
- Komplexes Reasoning und Analyse
- Lange Artikel/Berichte schreiben
- Detailliertes Code-Review (16K Kontext genügt)
- Professionelle Übersetzung (mit Nuancen)
- Akademische/technische Inhalte erstellen
- Aufgaben mit kritischem Denken

---

## 🚀 Başlatma

### İlk Kez
```bash
cd gemma-4-31b-it
./install.sh        # Model indir + container oluştur + başlat
```

### Sonraki Sefer
```bash
cd gemma-4-31b-it
./start.sh          # Container başlat (model cache'de)
```

### Durdurma (cache korunur)
```bash
./stop.sh
```

---

## 📡 API Erişim

### vLLM Doğrudan
```bash
# Model listesi
curl http://localhost:8008/v1/models

# Chat completion
curl -X POST http://localhost:8008/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma-4-31b-it",
    "messages": [{"role": "user", "content": "Hello"}],
    "max_tokens": 512
  }'
```

### LiteLLM Gateway Üzerinden
```bash
curl -X POST http://localhost:4000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma-4-31b-it",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

---

## 💾 Yönetim

| İşlem | Komut |
|-------|-------|
| **Durum Kontrol** | `./status.sh` |
| **Logları İzle** | `./logs.sh -f` |
| **Kaldır** | `./uninstall.sh` |

---

## 📊 Performans Tahmini

- **İlk Yükleme:** 5-10 dakika (model indir + CUDA graph capture)
- **Restart:** 2-3 saniye (cache'ten)
- **Çıktı Hızı:** 50-100 token/s (GPU'ya bağlı)

---

## 🔗 Kaynaklar

- **HF Sayfası:** https://huggingface.co/google/gemma-4-31B-it
- **vLLM Docs:** https://docs.vllm.ai/
- **Ana README:** `../README.md`

---

**Kurulum tarihi:** 2026-05-17
