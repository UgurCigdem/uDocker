# gemma-4-26b-a4b-it — vLLM Model

## 📋 Model Bilgisi

| Özellik | Değer |
|---------|-------|
| **Model Adı** | google/gemma-4-26B-A4B-it |
| **Parametreler** | 26B (MoE, 4B aktif) |
| **Mimari** | MoE (Gemma 4, 4B aktif) |
| **Boyut** | 52 GB disk |
| **GPU Bellek** | 0.55 (= 55%) |
| **Max Context** | 32768 tokens |
| **Quantization** | BF16 (bfloat16) |
| **Port** | 8007 |
| **Container** | `vllm-gemma-4-26b-a4b-it` |
| **Docker Image** | `vllm/vllm-openai:nightly-aarch64` |

---

## 🎯 Ne İş İçin Uygun?

🥇 MoE: 26B Qualität, 4B Geschwindigkeit — am effizientesten für DGX Spark

### Kullanım Senaryoları

- Schneller, intelligenter Allgemein-Chat (MoE → bandbreiteneffizient)
- Komplexes Reasoning (26B-Qualität)
- Lange, mehrstufige Gespräche
- Mehrsprachige Aufgaben (140+ Sprachen)
- Ideal für DGX Spark — nutzt die 270 GB/s Bandbreite am besten
- Produktiv-Deployment (Balance aus Geschwindigkeit + Qualität)
- Function Calling (fortgeschrittene Tool-Nutzung)

---

## 🚀 Başlatma

### İlk Kez
```bash
cd gemma-4-26b-a4b-it
./install.sh        # Model indir + container oluştur + başlat
```

### Sonraki Sefer
```bash
cd gemma-4-26b-a4b-it
./start.sh          # Container başlat (model cache'de)
```

### Durdurma (cache korunur)
```bash
./stop.sh
```

---

## 📡 API Erişim

### vLLM Doğrudan
```bash
# Model listesi
curl http://localhost:8007/v1/models

# Chat completion
curl -X POST http://localhost:8007/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma-4-26b-a4b-it",
    "messages": [{"role": "user", "content": "Hello"}],
    "max_tokens": 512
  }'
```

### LiteLLM Gateway Üzerinden
```bash
curl -X POST http://localhost:4000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma-4-26b-a4b-it",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

---

## 💾 Yönetim

| İşlem | Komut |
|-------|-------|
| **Durum Kontrol** | `./status.sh` |
| **Logları İzle** | `./logs.sh -f` |
| **Kaldır** | `./uninstall.sh` |

---

## 📊 Performans Tahmini

- **İlk Yükleme:** 5-10 dakika (model indir + CUDA graph capture)
- **Restart:** 2-3 saniye (cache'ten)
- **Çıktı Hızı:** 50-100 token/s (GPU'ya bağlı)

---

## 🔗 Kaynaklar

- **HF Sayfası:** https://huggingface.co/google/gemma-4-26B-A4B-it
- **vLLM Docs:** https://docs.vllm.ai/
- **Ana README:** `../README.md`

---

**Kurulum tarihi:** 2026-05-17
