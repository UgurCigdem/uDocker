#!/bin/bash
# Stop LiteLLM Proxy

set -e

echo "⏸ Stoppe LiteLLM Proxy..."
docker compose stop litellm-proxy

echo "✅ LiteLLM gestoppt"
