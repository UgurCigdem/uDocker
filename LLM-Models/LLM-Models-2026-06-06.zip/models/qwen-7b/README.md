# qwen-7b — vLLM Model

## 📋 Model Bilgisi

| Özellik | Değer |
|---------|-------|
| **Model Adı** | Qwen/Qwen2.5-7B-Instruct |
| **Parametreler** | 7B |
| **Mimari** | Dense (Qwen 2.5) |
| **Boyut** | 15 GB disk |
| **GPU Bellek** | 0.18 (= 18%) |
| **Max Context** | 32768 tokens |
| **Quantization** | FP16 (bfloat16) |
| **Port** | 8003 |
| **Container** | `vllm-qwen-7b` |
| **Docker Image** | `vllm/vllm-openai:latest` |

---

## 🎯 Ne İş İçin Uygun?

Allgemeiner Chat (gut auf Türkisch)

### Kullanım Senaryoları

- Natürlichsprachiger Chat auf Türkisch (gute Türkisch-Qualität)
- Übersetzung (TR ↔ EN, mehrsprachig)
- Textzusammenfassung
- Frage-Antwort (Allgemeinwissen)
- Inhaltserstellung (E-Mail, Nachricht, kurzer Artikel)
- Brainstorming — Ideen entwickeln
- Korrektur/Korrekturlesen

---

## 🚀 Başlatma

### İlk Kez
```bash
cd qwen-7b
./install.sh        # Model indir + container oluştur + başlat
```

### Sonraki Sefer
```bash
cd qwen-7b
./start.sh          # Container başlat (model cache'de)
```

### Durdurma (cache korunur)
```bash
./stop.sh
```

---

## 📡 API Erişim

### vLLM Doğrudan
```bash
# Model listesi
curl http://localhost:8003/v1/models

# Chat completion
curl -X POST http://localhost:8003/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen-7b",
    "messages": [{"role": "user", "content": "Hello"}],
    "max_tokens": 512
  }'
```

### LiteLLM Gateway Üzerinden
```bash
curl -X POST http://localhost:4000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen-7b",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

---

## 💾 Yönetim

| İşlem | Komut |
|-------|-------|
| **Durum Kontrol** | `./status.sh` |
| **Logları İzle** | `./logs.sh -f` |
| **Kaldır** | `./uninstall.sh` |

---

## 📊 Performans Tahmini

- **İlk Yükleme:** 5-10 dakika (model indir + CUDA graph capture)
- **Restart:** 2-3 saniye (cache'ten)
- **Çıktı Hızı:** 50-100 token/s (GPU'ya bağlı)

---

## 🔗 Kaynaklar

- **HF Sayfası:** https://huggingface.co/Qwen/Qwen2.5-7B-Instruct
- **vLLM Docs:** https://docs.vllm.ai/
- **Ana README:** `../README.md`

---

**Kurulum tarihi:** 2026-05-17
