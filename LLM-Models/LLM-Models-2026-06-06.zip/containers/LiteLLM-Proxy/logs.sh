#!/bin/bash
# Show LiteLLM Proxy logs

FOLLOW=false

if [ "$1" = "-f" ] || [ "$1" = "--follow" ]; then
    FOLLOW=true
fi

echo "📋 LiteLLM Proxy Logs"
if [ "$FOLLOW" = true ]; then
    echo "Verfolge (Strg+C zum Beenden)"
    docker compose logs -f litellm-proxy
else
    echo "Letzte 100 Zeilen"
    docker compose logs --tail=100 litellm-proxy
fi
