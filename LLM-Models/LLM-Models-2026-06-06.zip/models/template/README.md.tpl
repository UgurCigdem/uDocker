# ___MODEL_ID___ — vLLM Model

## 📋 Model Bilgisi

| Özellik | Değer |
|---------|-------|
| **Model Adı** | ___HF_ID___ |
| **Parametreler** | ___PARAMS_B___ |
| **Mimari** | ___ARCHITECTURE___ |
| **Boyut** | ___SIZE_GB___ GB disk |
| **GPU Bellek** | ___GPU_MEM___ (= ___GPU_MEM_PERCENT___%) |
| **Max Context** | ___MAX_LEN___ tokens |
| **Quantization** | ___QUANTIZATION___ |
| **Port** | ___PORT___ |
| **Container** | `vllm-___MODEL_ID___` |
| **Docker Image** | `___IMAGE___:___IMAGE_TAG___` |

---

## 🎯 Ne İş İçin Uygun?

___DESCRIPTION___

### Kullanım Senaryoları

___USE_CASES___

---

## 🚀 Başlatma

### İlk Kez
```bash
cd ___MODEL_ID___
./install.sh        # Model indir + container oluştur + başlat
```

### Sonraki Sefer
```bash
cd ___MODEL_ID___
./start.sh          # Container başlat (model cache'de)
```

### Durdurma (cache korunur)
```bash
./stop.sh
```

---

## 📡 API Erişim

### vLLM Doğrudan
```bash
# Model listesi
curl http://localhost:___PORT___/v1/models

# Chat completion
curl -X POST http://localhost:___PORT___/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "___MODEL_ID___",
    "messages": [{"role": "user", "content": "Hello"}],
    "max_tokens": 512
  }'
```

### LiteLLM Gateway Üzerinden
```bash
curl -X POST http://localhost:4000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "___MODEL_ID___",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

---

## 💾 Yönetim

| İşlem | Komut |
|-------|-------|
| **Durum Kontrol** | `./status.sh` |
| **Logları İzle** | `./logs.sh -f` |
| **Kaldır** | `./uninstall.sh` |

---

## 📊 Performans Tahmini

- **İlk Yükleme:** 5-10 dakika (model indir + CUDA graph capture)
- **Restart:** 2-3 saniye (cache'ten)
- **Çıktı Hızı:** 50-100 token/s (GPU'ya bağlı)

---

## 🔗 Kaynaklar

- **HF Sayfası:** https://huggingface.co/___HF_ID___
- **vLLM Docs:** https://docs.vllm.ai/
- **Ana README:** `../README.md`

---

**Kurulum tarihi:** 2026-05-17
