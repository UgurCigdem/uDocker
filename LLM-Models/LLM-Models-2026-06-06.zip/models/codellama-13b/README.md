# codellama-13b — vLLM Model

## 📋 Model Bilgisi

| Özellik | Değer |
|---------|-------|
| **Model Adı** | meta-llama/CodeLlama-13b-Instruct-hf |
| **Parametreler** | 13B |
| **Mimari** | Dense (Llama 2 / CodeLlama) |
| **Boyut** | 26 GB disk |
| **GPU Bellek** | 0.25 (= 25%) |
| **Max Context** | 100000 tokens |
| **Quantization** | FP16 (float16) |
| **Port** | 8005 |
| **Container** | `vllm-codellama-13b` |
| **Docker Image** | `vllm/vllm-openai:latest` |

---

## 🎯 Ne İş İçin Uygun?

Code-fokussiert, 100K Kontext

### Kullanım Senaryoları

- Refactoring in großen Codebasen (100K Kontext)
- Repository-weite Analyse — wenn alle Dateien einbezogen werden müssen
- Migrationsprojekte (z. B. Python 2→3, Vue 2→3)
- Legacy-Code prüfen und modernisieren
- Dokumentation erzeugen (lange Dateien)
- Code-Review-Assistent
- Analyse komplexer Algorithmen

---

## 🚀 Başlatma

### İlk Kez
```bash
cd codellama-13b
./install.sh        # Model indir + container oluştur + başlat
```

### Sonraki Sefer
```bash
cd codellama-13b
./start.sh          # Container başlat (model cache'de)
```

### Durdurma (cache korunur)
```bash
./stop.sh
```

---

## 📡 API Erişim

### vLLM Doğrudan
```bash
# Model listesi
curl http://localhost:8005/v1/models

# Chat completion
curl -X POST http://localhost:8005/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "codellama-13b",
    "messages": [{"role": "user", "content": "Hello"}],
    "max_tokens": 512
  }'
```

### LiteLLM Gateway Üzerinden
```bash
curl -X POST http://localhost:4000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "codellama-13b",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

---

## 💾 Yönetim

| İşlem | Komut |
|-------|-------|
| **Durum Kontrol** | `./status.sh` |
| **Logları İzle** | `./logs.sh -f` |
| **Kaldır** | `./uninstall.sh` |

---

## 📊 Performans Tahmini

- **İlk Yükleme:** 5-10 dakika (model indir + CUDA graph capture)
- **Restart:** 2-3 saniye (cache'ten)
- **Çıktı Hızı:** 50-100 token/s (GPU'ya bağlı)

---

## 🔗 Kaynaklar

- **HF Sayfası:** https://huggingface.co/meta-llama/CodeLlama-13b-Instruct-hf
- **vLLM Docs:** https://docs.vllm.ai/
- **Ana README:** `../README.md`

---

**Kurulum tarihi:** 2026-05-17
