#!/bin/bash
# Start LiteLLM Proxy

set -e

echo "▶ Starte LiteLLM Proxy..."
docker compose start litellm-proxy

echo "✅ LiteLLM gestartet"
echo "   Erreichbar: http://localhost:4000"
