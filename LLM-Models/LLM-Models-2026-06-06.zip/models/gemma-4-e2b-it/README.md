# gemma-4-e2b-it — vLLM Model

## 📋 Model Bilgisi

| Özellik | Değer |
|---------|-------|
| **Model Adı** | google/gemma-4-E2B-it |
| **Parametreler** | 5B (MatFormer) |
| **Mimari** | MatFormer (Gemma 4 Edge) |
| **Boyut** | 10 GB disk |
| **GPU Bellek** | 0.15 (= 15%) |
| **Max Context** | 32768 tokens |
| **Quantization** | BF16 (bfloat16) |
| **Port** | 8010 |
| **Container** | `vllm-gemma-4-e2b-it` |
| **Docker Image** | `vllm/vllm-openai:nightly-aarch64` |

---

## 🎯 Ne İş İçin Uygun?

🥈 MatFormer Edge: klein + schnell, multimodal

### Kullanım Senaryoları

- Aufgaben mit schneller Antwortzeit (Chatbot, Sofortempfehlung)
- Deployment mit wenig Ressourcen (Edge-/Mobile-Simulation)
- Einfaches Multimodal — Text + Bild Schnellabfrage
- Stapelverarbeitung (Batch Processing, hoher Durchsatz)
- Prompts ausprobieren/Prototyping
- Klassifizierungsaufgaben (Kategorie, Intent-Erkennung)
- Einfaches OCR + Frage-Antwort

---

## 🚀 Başlatma

### İlk Kez
```bash
cd gemma-4-e2b-it
./install.sh        # Model indir + container oluştur + başlat
```

### Sonraki Sefer
```bash
cd gemma-4-e2b-it
./start.sh          # Container başlat (model cache'de)
```

### Durdurma (cache korunur)
```bash
./stop.sh
```

---

## 📡 API Erişim

### vLLM Doğrudan
```bash
# Model listesi
curl http://localhost:8010/v1/models

# Chat completion
curl -X POST http://localhost:8010/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma-4-e2b-it",
    "messages": [{"role": "user", "content": "Hello"}],
    "max_tokens": 512
  }'
```

### LiteLLM Gateway Üzerinden
```bash
curl -X POST http://localhost:4000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma-4-e2b-it",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

---

## 💾 Yönetim

| İşlem | Komut |
|-------|-------|
| **Durum Kontrol** | `./status.sh` |
| **Logları İzle** | `./logs.sh -f` |
| **Kaldır** | `./uninstall.sh` |

---

## 📊 Performans Tahmini

- **İlk Yükleme:** 5-10 dakika (model indir + CUDA graph capture)
- **Restart:** 2-3 saniye (cache'ten)
- **Çıktı Hızı:** 50-100 token/s (GPU'ya bağlı)

---

## 🔗 Kaynaklar

- **HF Sayfası:** https://huggingface.co/google/gemma-4-E2B-it
- **vLLM Docs:** https://docs.vllm.ai/
- **Ana README:** `../README.md`

---

**Kurulum tarihi:** 2026-05-17
