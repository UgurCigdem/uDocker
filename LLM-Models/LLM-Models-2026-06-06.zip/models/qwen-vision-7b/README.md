# qwen-vision-7b — vLLM Model

## 📋 Model Bilgisi

| Özellik | Değer |
|---------|-------|
| **Model Adı** | Qwen/Qwen2.5-VL-7B-Instruct |
| **Parametreler** | 7B |
| **Mimari** | Dense+Vision (Qwen 2.5 VL) |
| **Boyut** | 16 GB disk |
| **GPU Bellek** | 0.22 (= 22%) |
| **Max Context** | 32768 tokens |
| **Quantization** | FP16 (bfloat16) |
| **Port** | 8002 |
| **Container** | `vllm-qwen-vision-7b` |
| **Docker Image** | `vllm/vllm-openai:latest` |

---

## 🎯 Ne İş İçin Uygun?

Bilderkennung + Chat

### Kullanım Senaryoları

- Bildbeschreibung — erklären, was auf einem Bild zu sehen ist
- OCR — Text aus Bild/Dokument extrahieren
- Diagramme/Grafiken interpretieren (Excel-, Tableau-Ausgaben)
- UI-Screenshot-Analyse (Fehlerberichte)
- Informationen aus PDF-/Dokumentseiten extrahieren
- Handschrifterkennung
- Diagramm-/Schema-Beschreibung

---

## 🚀 Başlatma

### İlk Kez
```bash
cd qwen-vision-7b
./install.sh        # Model indir + container oluştur + başlat
```

### Sonraki Sefer
```bash
cd qwen-vision-7b
./start.sh          # Container başlat (model cache'de)
```

### Durdurma (cache korunur)
```bash
./stop.sh
```

---

## 📡 API Erişim

### vLLM Doğrudan
```bash
# Model listesi
curl http://localhost:8002/v1/models

# Chat completion
curl -X POST http://localhost:8002/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen-vision-7b",
    "messages": [{"role": "user", "content": "Hello"}],
    "max_tokens": 512
  }'
```

### LiteLLM Gateway Üzerinden
```bash
curl -X POST http://localhost:4000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen-vision-7b",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

---

## 💾 Yönetim

| İşlem | Komut |
|-------|-------|
| **Durum Kontrol** | `./status.sh` |
| **Logları İzle** | `./logs.sh -f` |
| **Kaldır** | `./uninstall.sh` |

---

## 📊 Performans Tahmini

- **İlk Yükleme:** 5-10 dakika (model indir + CUDA graph capture)
- **Restart:** 2-3 saniye (cache'ten)
- **Çıktı Hızı:** 50-100 token/s (GPU'ya bağlı)

---

## 🔗 Kaynaklar

- **HF Sayfası:** https://huggingface.co/Qwen/Qwen2.5-VL-7B-Instruct
- **vLLM Docs:** https://docs.vllm.ai/
- **Ana README:** `../README.md`

---

**Kurulum tarihi:** 2026-05-17
