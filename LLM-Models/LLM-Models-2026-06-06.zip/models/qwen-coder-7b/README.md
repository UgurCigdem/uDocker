# qwen-coder-7b — vLLM Model

## 📋 Model Bilgisi

| Özellik | Değer |
|---------|-------|
| **Model Adı** | Qwen/Qwen2.5-Coder-7B-Instruct |
| **Parametreler** | 7B |
| **Mimari** | Dense (Qwen 2.5) |
| **Boyut** | 15 GB disk |
| **GPU Bellek** | 0.18 (= 18%) |
| **Max Context** | 32768 tokens |
| **Quantization** | FP16 (bfloat16) |
| **Port** | 8001 |
| **Container** | `vllm-qwen-coder-7b` |
| **Docker Image** | `vllm/vllm-openai:latest` |

---

## 🎯 Ne İş İçin Uygun?

Codegenerierung, Analyse, Refactoring

### Kullanım Senaryoları

- Neue Codeerstellung (Python, JS, Go, Rust, TypeScript, C++ …)
- Code-Refactoring — lange Funktionen vereinfachen
- Bugfix-Vorschläge und Fehlersuche
- Unit- und Integrationstests schreiben
- API-Endpunkte erzeugen (FastAPI, Express usw.)
- Algorithmen/Datenstrukturen vermitteln
- Code kommentieren und dokumentieren

---

## 🚀 Başlatma

### İlk Kez
```bash
cd qwen-coder-7b
./install.sh        # Model indir + container oluştur + başlat
```

### Sonraki Sefer
```bash
cd qwen-coder-7b
./start.sh          # Container başlat (model cache'de)
```

### Durdurma (cache korunur)
```bash
./stop.sh
```

---

## 📡 API Erişim

### vLLM Doğrudan
```bash
# Model listesi
curl http://localhost:8001/v1/models

# Chat completion
curl -X POST http://localhost:8001/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen-coder-7b",
    "messages": [{"role": "user", "content": "Hello"}],
    "max_tokens": 512
  }'
```

### LiteLLM Gateway Üzerinden
```bash
curl -X POST http://localhost:4000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen-coder-7b",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

---

## 💾 Yönetim

| İşlem | Komut |
|-------|-------|
| **Durum Kontrol** | `./status.sh` |
| **Logları İzle** | `./logs.sh -f` |
| **Kaldır** | `./uninstall.sh` |

---

## 📊 Performans Tahmini

- **İlk Yükleme:** 5-10 dakika (model indir + CUDA graph capture)
- **Restart:** 2-3 saniye (cache'ten)
- **Çıktı Hızı:** 50-100 token/s (GPU'ya bağlı)

---

## 🔗 Kaynaklar

- **HF Sayfası:** https://huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct
- **vLLM Docs:** https://docs.vllm.ai/
- **Ana README:** `../README.md`

---

**Kurulum tarihi:** 2026-05-17
