#!/bin/bash
# Generate docker-compose.yml + sh files from models-registry.yaml
# Usage: ./generate.sh
# Requires: Python 3 with PyYAML

set -e

REGISTRY="models-registry.yaml"
TEMPLATE_DIR="models/template"
MODELS_DIR="models"

echo "🔧 Generiere Modell-Konfigurationen..."
echo ""

# Check registry exists
if [ ! -f "$REGISTRY" ]; then
    echo "❌ $REGISTRY nicht gefunden"
    exit 1
fi

# Check template dir exists
if [ ! -d "$TEMPLATE_DIR" ]; then
    echo "❌ $TEMPLATE_DIR nicht gefunden"
    exit 1
fi

# Use Python to parse YAML and generate files
python3 << 'PYTHON_SCRIPT'
import yaml
import os
import json
from pathlib import Path

REGISTRY = "models-registry.yaml"
TEMPLATE_DIR = "models/template"
MODELS_DIR = "models"

# Load registry
with open(REGISTRY, 'r') as f:
    registry = yaml.safe_load(f)

MODEL_COUNT = 0

for model_config in registry.get('models', []):
    model_id = model_config.get('id')
    hf_id = model_config.get('hf_id')
    params_b = model_config.get('params_b', 'N/A')
    architecture = model_config.get('architecture', 'Dense')
    port = model_config.get('port')
    gpu_mem = model_config.get('gpu_mem')
    max_len = model_config.get('max_len')
    size_gb = model_config.get('size_gb')
    quantization = model_config.get('quantization', 'FP16')
    image = model_config.get('image', 'vllm/vllm-openai')
    image_tag = model_config.get('image_tag', 'latest')
    extra_args = model_config.get('extra_args', '')
    description = model_config.get('description', '')
    use_cases = model_config.get('use_cases', []) or []

    # Create model directory
    model_dir = Path(MODELS_DIR) / model_id
    model_dir.mkdir(parents=True, exist_ok=True)

    # Convert use_cases list to markdown bullets
    use_cases_md = '\n'.join(f'- {uc}' for uc in use_cases) if use_cases else '- (Szenario nicht definiert)'

    # use_cases als JSON-Array-String fuer das Docker-Label (uDocker liest dies).
    # Der Wert steht im Template in einfachen YAML-Anfuehrungszeichen -> einfache
    # Anfuehrungszeichen im Inhalt verdoppeln (YAML-Escaping).
    use_cases_label = json.dumps(use_cases, ensure_ascii=False).replace("'", "''")

    # Replacements dict
    gpu_mem_percent = int(float(gpu_mem) * 100)
    replacements = {
        '___MODEL_ID___': str(model_id),
        '___HF_ID___': str(hf_id),
        '___PARAMS_B___': str(params_b),
        '___ARCHITECTURE___': str(architecture),
        '___PORT___': str(port),
        '___GPU_MEM___': str(gpu_mem),
        '___GPU_MEM_PERCENT___': str(gpu_mem_percent),
        '___MAX_LEN___': str(max_len),
        '___SIZE_GB___': str(size_gb),
        '___QUANTIZATION___': str(quantization),
        '___IMAGE___': str(image),
        '___IMAGE_TAG___': str(image_tag),
        '___EXTRA_ARGS___': str(extra_args),
        '___DESCRIPTION___': str(description),
        '___USE_CASES___': use_cases_md,
        '___USE_CASES_LABEL___': use_cases_label,
    }

    # Generate docker-compose.yml
    template_file = Path(TEMPLATE_DIR) / 'docker-compose.yml.tpl'
    if template_file.exists():
        with open(template_file, 'r') as f:
            content = f.read()
        for placeholder, value in replacements.items():
            content = content.replace(placeholder, value)
        with open(model_dir / 'docker-compose.yml', 'w') as f:
            f.write(content)

    # Generate .env.example
    template_file = Path(TEMPLATE_DIR) / '.env.tpl'
    if template_file.exists():
        with open(template_file, 'r') as f:
            content = f.read()
        for placeholder, value in replacements.items():
            content = content.replace(placeholder, value)
        with open(model_dir / '.env.example', 'w') as f:
            f.write(content)

    # Generate sh files
    for script in ['install', 'start', 'stop', 'uninstall', 'status', 'logs']:
        template_file = Path(TEMPLATE_DIR) / f'{script}.sh.tpl'
        if template_file.exists():
            with open(template_file, 'r') as f:
                content = f.read()
            for placeholder, value in replacements.items():
                content = content.replace(placeholder, value)

            output_file = model_dir / f'{script}.sh'
            with open(output_file, 'w') as f:
                f.write(content)

            # Make executable
            os.chmod(output_file, 0o755)

    # Generate README.md
    template_file = Path(TEMPLATE_DIR) / 'README.md.tpl'
    if template_file.exists():
        with open(template_file, 'r') as f:
            content = f.read()
        for placeholder, value in replacements.items():
            content = content.replace(placeholder, value)
        with open(model_dir / 'README.md', 'w') as f:
            f.write(content)

    print(f"✅ Generiert: {model_id}")
    MODEL_COUNT += 1

print(f"\n✅ {MODEL_COUNT} Modell-Konfigurationen generiert")
PYTHON_SCRIPT

# Generate setup-network.sh
cat > setup-network.sh << 'EOF'
#!/bin/bash
# Create ai-net Docker network (external, shared by all models)

set -e

NETWORK_NAME="ai-net"

echo "🌐 Richte Docker-Netzwerk ein: $NETWORK_NAME"

if docker network ls | grep -q "$NETWORK_NAME"; then
    echo "✅ Netzwerk $NETWORK_NAME existiert bereits"
else
    docker network create "$NETWORK_NAME" --driver bridge
    echo "✅ Netzwerk $NETWORK_NAME erstellt"
fi

echo ""
echo "Netzwerk bereit. Jetzt kannst du ausführen:"
echo "  cd models/coder && ./install.sh"
EOF
chmod +x setup-network.sh

# Generate all-models-start.sh
cat > all-models-start.sh << 'EOF'
#!/bin/bash
# Start all models in parallel

set -e

echo "▶ Starte alle Modelle..."

for dir in models/*/; do
    MODEL_ID=$(basename "$dir")
    (
        cd "$dir"
        if [ -f "docker-compose.yml" ]; then
            echo "  Starte $MODEL_ID..."
            docker compose start vllm-$MODEL_ID 2>/dev/null || true
        fi
    ) &
done

wait

echo "✅ Alle Modelle gestartet"
echo ""
./all-models-status.sh
EOF
chmod +x all-models-start.sh

# Generate all-models-stop.sh
cat > all-models-stop.sh << 'EOF'
#!/bin/bash
# Stop all models in parallel (cache preserved)

set -e

echo "⏸ Stoppe alle Modelle..."

for dir in models/*/; do
    MODEL_ID=$(basename "$dir")
    (
        cd "$dir"
        if [ -f "docker-compose.yml" ]; then
            echo "  Stoppe $MODEL_ID..."
            docker compose stop vllm-$MODEL_ID 2>/dev/null || true
        fi
    ) &
done

wait

echo "✅ Alle Modelle gestoppt (Cache bleibt erhalten)"
EOF
chmod +x all-models-stop.sh

# Generate all-models-status.sh
cat > all-models-status.sh << 'EOF'
#!/bin/bash
# Show status of all models

echo "📊 vLLM Modell-Status"
echo ""

TOTAL_GPU=0
RUNNING_MODELS=0

for dir in models/*/; do
    MODEL_ID=$(basename "$dir")
    if [ -f "$dir/docker-compose.yml" ]; then
        cd "$dir"

        if docker compose ps vllm-$MODEL_ID 2>/dev/null | grep -q "Up"; then
            echo "✅ $MODEL_ID [LÄUFT]"
            RUNNING_MODELS=$((RUNNING_MODELS + 1))

            # Extract GPU_MEM from docker-compose.yml
            GPU_MEM=$(grep -oP 'gpu-memory-utilization \K[0-9.]+' docker-compose.yml || echo "0")
            TOTAL_GPU=$(echo "$TOTAL_GPU + $GPU_MEM" | bc)
        else
            echo "⏸ $MODEL_ID [GESTOPPT]"
        fi

        cd - > /dev/null
    fi
done

echo ""
echo "📊 Zusammenfassung:"
echo "   Aktiv: $RUNNING_MODELS Modell(e)"
echo "   GPU gesamt: ${TOTAL_GPU}00%"
EOF
chmod +x all-models-status.sh

echo ""
echo "════════════════════════════════════════"
echo "Nächste Schritte:"
echo "  1. ./setup-network.sh              (Docker-Netzwerk erstellen)"
echo "  2. cd models/coder && ./install.sh (erstes Modell installieren)"
echo "  3. ./vllm-ctl                      (interaktives Menü starten)"
echo ""
echo "Oder alle Modelle gleichzeitig laden:"
echo "  for dir in models/*/; do"
echo "    (cd \$dir && ./install.sh) &"
echo "  done"
echo "  wait"
echo ""
