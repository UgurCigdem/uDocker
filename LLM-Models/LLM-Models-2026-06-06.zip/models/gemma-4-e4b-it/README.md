# gemma-4-e4b-it — vLLM Model

## 📋 Model Bilgisi

| Özellik | Değer |
|---------|-------|
| **Model Adı** | google/gemma-4-E4B-it |
| **Parametreler** | 8B (MatFormer) |
| **Mimari** | MatFormer (Gemma 4) |
| **Boyut** | 16 GB disk |
| **GPU Bellek** | 0.2 (= 20%) |
| **Max Context** | 32768 tokens |
| **Quantization** | BF16 (bfloat16) |
| **Port** | 8009 |
| **Container** | `vllm-gemma-4-e4b-it` |
| **Docker Image** | `vllm/vllm-openai:nightly-aarch64` |

---

## 🎯 Ne İş İçin Uygun?

🥈 MatFormer: Any-to-Any multimodal (Text+Bild+Audio+Video)

### Kullanım Senaryoları

- Bild + Text-Aufgaben (Image-Text-to-Text)
- Audio-Transkription (Speech-to-Text)
- Video-Zusammenfassung und Inhaltsanalyse
- Multimodales RAG (Bild + Text gemeinsam)
- Flexibles Deployment — MatFormer-Größe zur Laufzeit anpassbar
- Gemischt-modale Frage-Antwort (gesprochene Frage zu einem Bild)
- Dokumentverarbeitung (Text + Tabellen + Grafiken)

---

## 🚀 Başlatma

### İlk Kez
```bash
cd gemma-4-e4b-it
./install.sh        # Model indir + container oluştur + başlat
```

### Sonraki Sefer
```bash
cd gemma-4-e4b-it
./start.sh          # Container başlat (model cache'de)
```

### Durdurma (cache korunur)
```bash
./stop.sh
```

---

## 📡 API Erişim

### vLLM Doğrudan
```bash
# Model listesi
curl http://localhost:8009/v1/models

# Chat completion
curl -X POST http://localhost:8009/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma-4-e4b-it",
    "messages": [{"role": "user", "content": "Hello"}],
    "max_tokens": 512
  }'
```

### LiteLLM Gateway Üzerinden
```bash
curl -X POST http://localhost:4000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma-4-e4b-it",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

---

## 💾 Yönetim

| İşlem | Komut |
|-------|-------|
| **Durum Kontrol** | `./status.sh` |
| **Logları İzle** | `./logs.sh -f` |
| **Kaldır** | `./uninstall.sh` |

---

## 📊 Performans Tahmini

- **İlk Yükleme:** 5-10 dakika (model indir + CUDA graph capture)
- **Restart:** 2-3 saniye (cache'ten)
- **Çıktı Hızı:** 50-100 token/s (GPU'ya bağlı)

---

## 🔗 Kaynaklar

- **HF Sayfası:** https://huggingface.co/google/gemma-4-E4B-it
- **vLLM Docs:** https://docs.vllm.ai/
- **Ana README:** `../README.md`

---

**Kurulum tarihi:** 2026-05-17
